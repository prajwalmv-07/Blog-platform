# BlogSpace – Blog Platform with Comments (MERN)

Full-stack blogging platform: users register, log in (JWT), create/edit/delete their own posts and comment on any post.

**Stack:** React (Vite) · Node.js + Express · MongoDB (Mongoose) · JWT · bcrypt · express-validator · plain CSS

## Features
- Registration & login with validation (client + server), bcrypt-hashed passwords (12 rounds)
- JWT authentication, protected routes, logout
- Posts: create, list (search + pagination), view, edit, delete (owner only)
- Comments: add, list with author/date, delete own, empty-comment validation
- RESTful API, central error handling, correct HTTP status codes (400/401/403/404/409)
- Responsive UI with loading, error and success messages

## Folder structure
```
blog-platform/
├── server/  (config, models, middleware, routes, server.js, seed.js)
└── client/  (src/components, src/pages, src/context, api.js, App.jsx)
```

## Database schema
- **User**: name, email (unique), password (hashed, hidden by default), timestamps
- **Post**: title, content, author → User, timestamps
- **Comment**: text, post → Post, author → User, timestamps
Relationships: User 1—N Post, Post 1—N Comment, User 1—N Comment. Deleting a post deletes its comments.

## API
| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | /api/auth/register | – | Register |
| POST | /api/auth/login | – | Login, returns JWT |
| GET | /api/auth/me | ✔ | Current user |
| GET | /api/users/:id | – | Profile + posts |
| GET | /api/posts?page&limit&search | – | List posts |
| GET | /api/posts/:id | – | Single post |
| POST | /api/posts | ✔ | Create post |
| PUT | /api/posts/:id | ✔ owner | Update post |
| DELETE | /api/posts/:id | ✔ owner | Delete post + comments |
| GET | /api/posts/:postId/comments | – | List comments |
| POST | /api/posts/:postId/comments | ✔ | Add comment |
| DELETE | /api/comments/:id | ✔ owner | Delete comment |

## Setup
1. Install Node.js 18+ and MongoDB (local) or create a free MongoDB Atlas cluster.
2. Backend:
```bash
cd server
npm install
cp .env.example .env      # Windows: copy .env.example .env
# edit .env: set JWT_SECRET to a long random string; set MONGO_URI (Atlas URI if using Atlas)
npm run seed              # optional sample data
npm run dev               # http://localhost:5000
```
3. Frontend (new terminal):
```bash
cd client
npm install
npm run dev               # http://localhost:5173
```
MongoDB creates the database and collections automatically on first write; no manual SQL/schema step is needed.

## Sample data (after `npm run seed`)
- alice@example.com / Password123
- bob@example.com / Password123
- 3 posts and 4 comments

## Testing
Manual flow: Register → Login → Home → Create post → Open post → Comment → Edit/Delete own post → Logout.
Checks: log in as Bob and confirm Edit/Delete buttons do not appear on Alice's posts; empty comment shows an error; short password shows an error.

API tests with curl:
```bash
curl http://localhost:5000/api/health
curl -X POST http://localhost:5000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"alice@example.com","password":"Password123"}'
# copy the token, then:
curl -X POST http://localhost:5000/api/posts -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" -d '{"title":"Test post","content":"This is a test post body."}'
# no token -> 401, someone else's post -> 403, bad id -> 400, missing post -> 404
curl -X PUT http://localhost:5000/api/posts/POST_ID -H "Authorization: Bearer BOB_TOKEN" \
  -H "Content-Type: application/json" -d '{"title":"Hack","content":"Not allowed edit"}'
```

## Submission tips
Push to GitHub with `.env` excluded (already in .gitignore), keep `.env.example`, add screenshots to the README, and make sure the repo link is public.
