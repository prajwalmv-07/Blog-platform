const express = require('express');
const User = require('../models/User');
const Post = require('../models/Post');

const router = express.Router();

// GET /api/users/:id  -> public profile + that user's posts
router.get('/:id', async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select('name createdAt');
    if (!user) return res.status(404).json({ message: 'User not found.' });
    const posts = await Post.find({ author: user._id }).sort('-createdAt');
    res.json({ user, posts });
  } catch (err) { next(err); }
});

module.exports = router;
