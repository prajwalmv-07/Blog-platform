const express = require('express');
const Comment = require('../models/Comment');
const protect = require('../middleware/auth');

const router = express.Router();

// DELETE /api/comments/:id  (comment owner only)
router.delete('/:id', protect, async (req, res, next) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found.' });
    if (String(comment.author) !== String(req.user._id)) {
      return res.status(403).json({ message: 'You can only delete your own comments.' });
    }
    await comment.deleteOne();
    res.json({ message: 'Comment deleted.' });
  } catch (err) { next(err); }
});

module.exports = router;
