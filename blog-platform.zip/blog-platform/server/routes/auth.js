const express = require('express');
const jwt = require('jsonwebtoken');
const { body } = require('express-validator');
const User = require('../models/User');
const protect = require('../middleware/auth');
const validate = require('../middleware/validate');

const router = express.Router();

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

const userPayload = (u) => ({ id: u._id, name: u.name, email: u.email });

// POST /api/auth/register
router.post(
  '/register',
  [
    body('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters.'),
    body('email').trim().isEmail().withMessage('Enter a valid email.').normalizeEmail(),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters.'),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { name, email, password } = req.body;
      if (await User.findOne({ email })) {
        return res.status(409).json({ message: 'That email is already registered.' });
      }
      const user = await User.create({ name, email, password });
      res.status(201).json({ token: signToken(user._id), user: userPayload(user) });
    } catch (err) { next(err); }
  }
);

// POST /api/auth/login
router.post(
  '/login',
  [
    body('email').trim().isEmail().withMessage('Enter a valid email.').normalizeEmail(),
    body('password').notEmpty().withMessage('Password is required.'),
  ],
  validate,
  async (req, res, next) => {
    try {
      const user = await User.findOne({ email: req.body.email }).select('+password');
      if (!user || !(await user.comparePassword(req.body.password))) {
        return res.status(401).json({ message: 'Invalid email or password.' });
      }
      res.json({ token: signToken(user._id), user: userPayload(user) });
    } catch (err) { next(err); }
  }
);

// GET /api/auth/me  (current logged-in user)
router.get('/me', protect, (req, res) => res.json({ user: userPayload(req.user) }));

module.exports = router;
