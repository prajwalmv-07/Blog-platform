const express = require('express');
const { body } = require('express-validator');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const protect = require('../middleware/auth');
const validate = require('../middleware/validate');

const router = express.Router();

const postRules = [
  body('title').trim().isLength({ min: 3, max: 150 }).withMessage('Title must be 3-150 characters.'),
  body('content').trim().isLength({ min: 10 }).withMessage('Content must be at least 10 characters.'),
];
const commentRules = [
  body('text').trim().notEmpty().withMessage('Comment cannot be empty.')
    .isLength({ max: 1000 }).withMessage('Comment is too long (max 1000).'),
];

// GET /api/posts?page=1&limit=6&search=abc
router.get('/', async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 6, 1), 50);
    const filter = {};
    if (req.query.search) {
      const safe = String(req.query.search).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      filter.title = new RegExp(safe, 'i');
    }
    const [posts, total] = await Promise.all([
      Post.find(filter).populate('author', 'name').sort('-createdAt')
        .skip((page - 1) * limit).limit(limit).lean(),
      Post.countDocuments(filter),
    ]);
    const ids = posts.map((p) => p._id);
    const counts = await Comment.aggregate([
      { $match: { post: { $in: ids } } },
      { $group: { _id: '$post', n: { $sum: 1 } } },
    ]);
    const map = Object.fromEntries(counts.map((c) => [String(c._id), c.n]));
    posts.forEach((p) => { p.commentCount = map[String(p._id)] || 0; });
    res.json({ posts, page, pages: Math.ceil(total / limit) || 1, total });
  } catch (err) { next(err); }
});

// GET /api/posts/:id
router.get('/:id', async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'name');
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    res.json({ post });
  } catch (err) { next(err); }
});

// POST /api/posts
router.post('/', protect, postRules, validate, async (req, res, next) => {
  try {
    const post = await Post.create({
      title: req.body.title, content: req.body.content, author: req.user._id,
    });
    await post.populate('author', 'name');
    res.status(201).json({ post });
  } catch (err) { next(err); }
});

// PUT /api/posts/:id  (owner only)
router.put('/:id', protect, postRules, validate, async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    if (String(post.author) !== String(req.user._id)) {
      return res.status(403).json({ message: 'You can only edit your own posts.' });
    }
    post.title = req.body.title;
    post.content = req.body.content;
    await post.save();
    await post.populate('author', 'name');
    res.json({ post });
  } catch (err) { next(err); }
});

// DELETE /api/posts/:id  (owner only, also removes its comments)
router.delete('/:id', protect, async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found.' });
    if (String(post.author) !== String(req.user._id)) {
      return res.status(403).json({ message: 'You can only delete your own posts.' });
    }
    await Comment.deleteMany({ post: post._id });
    await post.deleteOne();
    res.json({ message: 'Post deleted.' });
  } catch (err) { next(err); }
});

// GET /api/posts/:postId/comments
router.get('/:postId/comments', async (req, res, next) => {
  try {
    if (!(await Post.exists({ _id: req.params.postId }))) {
      return res.status(404).json({ message: 'Post not found.' });
    }
    const comments = await Comment.find({ post: req.params.postId })
      .populate('author', 'name').sort('-createdAt');
    res.json({ comments });
  } catch (err) { next(err); }
});

// POST /api/posts/:postId/comments
router.post('/:postId/comments', protect, commentRules, validate, async (req, res, next) => {
  try {
    if (!(await Post.exists({ _id: req.params.postId }))) {
      return res.status(404).json({ message: 'Post not found.' });
    }
    const comment = await Comment.create({
      text: req.body.text, post: req.params.postId, author: req.user._id,
    });
    await comment.populate('author', 'name');
    res.status(201).json({ comment });
  } catch (err) { next(err); }
});

module.exports = router;
