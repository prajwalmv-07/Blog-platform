require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Post = require('./models/Post');
const Comment = require('./models/Comment');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany(), Post.deleteMany(), Comment.deleteMany()]);

  const alice = await User.create({ name: 'Alice Rao', email: 'alice@example.com', password: 'Password123' });
  const bob = await User.create({ name: 'Bob Kumar', email: 'bob@example.com', password: 'Password123' });

  const p1 = await Post.create({
    title: 'Getting Started with React',
    content: 'React lets you build UIs from small reusable components. Start with Vite, learn props and state, then explore hooks like useEffect.',
    author: alice._id,
  });
  const p2 = await Post.create({
    title: 'Why JWT for Authentication?',
    content: 'JSON Web Tokens let the server verify who you are without storing sessions. Always keep the secret in environment variables and hash passwords with bcrypt.',
    author: bob._id,
  });
  const p3 = await Post.create({
    title: 'MongoDB Relationships Explained',
    content: 'In MongoDB you can reference documents by ObjectId. Users have many posts, and posts have many comments, linked using ref fields and populate().',
    author: alice._id,
  });

  await Comment.create([
    { text: 'Great intro, thanks for sharing!', post: p1._id, author: bob._id },
    { text: 'I would add a section on React Router.', post: p1._id, author: alice._id },
    { text: 'Very clear explanation of JWT.', post: p2._id, author: alice._id },
    { text: 'populate() saved me so much time.', post: p3._id, author: bob._id },
  ]);

  console.log('Seeded. Login: alice@example.com / Password123  or  bob@example.com / Password123');
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
