import { Link, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import PostDetail from './pages/PostDetail.jsx';
import PostForm from './pages/PostForm.jsx';

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/posts/new" element={<ProtectedRoute><PostForm /></ProtectedRoute>} />
          <Route path="/posts/:id/edit" element={<ProtectedRoute><PostForm /></ProtectedRoute>} />
          <Route path="/posts/:id" element={<PostDetail />} />
          <Route path="*" element={<div className="center-msg">Page not found. <Link to="/" className="link">Go home</Link></div>} />
        </Routes>
      </main>
      <footer className="footer">© {new Date().getFullYear()} BlogSpace</footer>
    </>
  );
}
