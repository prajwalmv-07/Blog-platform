import { Link } from 'react-router-dom';
import { formatDate } from '../api.js';

export default function PostCard({ post }) {
  const excerpt = post.content.length > 160 ? post.content.slice(0, 160) + '…' : post.content;
  return (
    <article className="card post-card">
      <h2><Link to={`/posts/${post._id}`}>{post.title}</Link></h2>
      <p className="meta">By {post.author?.name || 'Unknown'} · {formatDate(post.createdAt)}</p>
      <p className="excerpt">{excerpt}</p>
      <div className="card-footer">
        <span className="meta">💬 {post.commentCount ?? 0} comments</span>
        <Link to={`/posts/${post._id}`} className="link">Read more →</Link>
      </div>
    </article>
  );
}
