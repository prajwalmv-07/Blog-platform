import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, formatDate } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import Alert from './Alert.jsx';

export default function Comments({ postId }) {
  const { user } = useAuth();
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    api(`/posts/${postId}/comments`)
      .then((d) => setComments(d.comments))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [postId]);

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!text.trim()) return setError('Comment cannot be empty.');
    setBusy(true);
    try {
      const d = await api(`/posts/${postId}/comments`, { method: 'POST', body: { text } });
      setComments([d.comment, ...comments]);
      setText('');
      setSuccess('Comment added.');
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this comment?')) return;
    setError(''); setSuccess('');
    try {
      await api(`/comments/${id}`, { method: 'DELETE' });
      setComments(comments.filter((c) => c._id !== id));
      setSuccess('Comment deleted.');
    } catch (err) { setError(err.message); }
  };

  return (
    <section className="comments">
      <h3>Comments ({comments.length})</h3>
      <Alert type="error">{error}</Alert>
      <Alert type="success">{success}</Alert>

      {user ? (
        <form onSubmit={submit} className="comment-form">
          <textarea rows="3" placeholder="Write a comment..." value={text}
            onChange={(e) => setText(e.target.value)} maxLength={1000} />
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Posting...' : 'Post comment'}</button>
        </form>
      ) : (
        <p className="meta"><Link to="/login" className="link">Log in</Link> to join the discussion.</p>
      )}

      {loading ? <p className="meta">Loading comments...</p> :
        comments.length === 0 ? <p className="meta">No comments yet. Be the first!</p> :
        comments.map((c) => (
          <div className="comment" key={c._id}>
            <div className="comment-head">
              <strong>{c.author?.name || 'Unknown'}</strong>
              <span className="meta">{formatDate(c.createdAt)}</span>
            </div>
            <p>{c.text}</p>
            {user && c.author?._id === user.id && (
              <button className="btn btn-danger btn-sm" onClick={() => remove(c._id)}>Delete</button>
            )}
          </div>
        ))}
    </section>
  );
}
