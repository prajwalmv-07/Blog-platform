import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { api } from '../api.js';
import PostCard from '../components/PostCard.jsx';
import Alert from '../components/Alert.jsx';

export default function Home() {
  const location = useLocation();
  const [posts, setPosts] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true); setError('');
    api(`/posts?page=${page}&limit=6&search=${encodeURIComponent(query)}`)
      .then((d) => { setPosts(d.posts); setPages(d.pages); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [page, query]);

  const onSearch = (e) => { e.preventDefault(); setPage(1); setQuery(search.trim()); };

  return (
    <div className="container">
      <Alert type="success">{location.state?.success}</Alert>
      <div className="page-head">
        <h1>Latest posts</h1>
        <form className="search" onSubmit={onSearch}>
          <input placeholder="Search by title..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <button className="btn btn-primary">Search</button>
        </form>
      </div>
      <Alert type="error">{error}</Alert>
      {loading ? <div className="center-msg">Loading posts...</div> :
        posts.length === 0 && !error ? <div className="center-msg">No posts found.</div> : (
          <div className="grid">{posts.map((p) => <PostCard key={p._id} post={p} />)}</div>
        )}
      {pages > 1 && (
        <div className="pagination">
          <button className="btn btn-outline btn-sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span>Page {page} of {pages}</span>
          <button className="btn btn-outline btn-sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
