import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Alert from '../components/Alert.jsx';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.name.trim().length < 2) return setError('Name must be at least 2 characters.');
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError('Enter a valid email address.');
    if (form.password.length < 6) return setError('Password must be at least 6 characters.');
    if (form.password !== form.confirm) return setError('Passwords do not match.');
    setBusy(true);
    try {
      await register(form.name.trim(), form.email, form.password);
      navigate('/', { state: { success: 'Account created. Welcome!' } });
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="auth-wrap">
      <form className="card auth-card" onSubmit={submit} noValidate>
        <h1>Create account</h1>
        <Alert type="error">{error}</Alert>
        <label>Name<input name="name" value={form.name} onChange={change} autoComplete="name" /></label>
        <label>Email<input type="email" name="email" value={form.email} onChange={change} autoComplete="email" /></label>
        <label>Password<input type="password" name="password" value={form.password} onChange={change} autoComplete="new-password" /></label>
        <label>Confirm password<input type="password" name="confirm" value={form.confirm} onChange={change} autoComplete="new-password" /></label>
        <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Creating...' : 'Register'}</button>
        <p className="meta center">Already registered? <Link to="/login" className="link">Login</Link></p>
      </form>
    </div>
  );
}
