import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import Alert from '../components/Alert.jsx';

// Used for both "Create" (/posts/new) and "Edit" (/posts/:id/edit)
export default function PostForm() {
  const { id } = useParams();
  const editing = Boolean(id);
  const { user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: '', content: '' });
  const [loading, setLoading] = useState(editing);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!editing) return;
    api(`/posts/${id}`)
      .then(({ post }) => {
        if (post.author._id !== user.id) { setError('You can only edit your own posts.'); return; }
        setForm({ title: post.title, content: post.content });
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [id, editing, user.id]);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.title.trim().length < 3) return setError('Title must be at least 3 characters.');
    if (form.content.trim().length < 10) return setError('Content must be at least 10 characters.');
    setBusy(true);
    try {
      const d = editing
        ? await api(`/posts/${id}`, { method: 'PUT', body: form })
        : await api('/posts', { method: 'POST', body: form });
      navigate(`/posts/${d.post._id}`, { state: { success: editing ? 'Post updated.' : 'Post published.' } });
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  if (loading) return <div className="center-msg">Loading...</div>;

  return (
    <div className="container narrow">
      <form className="card" onSubmit={submit} noValidate>
        <h1>{editing ? 'Edit post' : 'Write a new post'}</h1>
        <Alert type="error">{error}</Alert>
        <label>Title<input name="title" value={form.title} onChange={change} maxLength={150} /></label>
        <label>Content<textarea name="content" rows="12" value={form.content} onChange={change} /></label>
        <div className="actions">
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : editing ? 'Save changes' : 'Publish'}</button>
          <button type="button" className="btn btn-outline" onClick={() => navigate(-1)}>Cancel</button>
        </div>
      </form>
    </div>
  );
}
