import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Alert from '../components/Alert.jsx';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState(location.state?.error || '');
  const [busy, setBusy] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError('Enter a valid email address.');
    if (!form.password) return setError('Password is required.');
    setBusy(true);
    try {
      await login(form.email, form.password);
      navigate(location.state?.from || '/', { state: { success: 'Logged in successfully.' } });
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="auth-wrap">
      <form className="card auth-card" onSubmit={submit} noValidate>
        <h1>Welcome back</h1>
        <Alert type="success">{location.state?.success}</Alert>
        <Alert type="error">{error}</Alert>
        <label>Email<input type="email" name="email" value={form.email} onChange={change} autoComplete="email" /></label>
        <label>Password<input type="password" name="password" value={form.password} onChange={change} autoComplete="current-password" /></label>
        <button className="btn btn-primary btn-block" disabled={busy}>{busy ? 'Logging in...' : 'Login'}</button>
        <p className="meta center">No account? <Link to="/register" className="link">Register</Link></p>
      </form>
    </div>
  );
}
