import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api, formatDate } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import Comments from '../components/Comments.jsx';
import Alert from '../components/Alert.jsx';

export default function PostDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    api(`/posts/${id}`)
      .then((d) => setPost(d.post))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [id]);

  const remove = async () => {
    if (!window.confirm('Delete this post and all its comments?')) return;
    try {
      await api(`/posts/${id}`, { method: 'DELETE' });
      navigate('/', { state: { success: 'Post deleted.' } });
    } catch (err) { setError(err.message); }
  };

  if (loading) return <div className="center-msg">Loading post...</div>;
  if (!post) return (
    <div className="container"><Alert type="error">{error || 'Post not found.'}</Alert>
      <Link to="/" className="link">← Back to posts</Link></div>
  );

  const isOwner = user && post.author?._id === user.id;

  return (
    <div className="container narrow">
      <Link to="/" className="link">← Back to posts</Link>
      <Alert type="success">{location.state?.success}</Alert>
      <Alert type="error">{error}</Alert>
      <article className="card post-full">
        <h1>{post.title}</h1>
        <p className="meta">By {post.author?.name || 'Unknown'} · {formatDate(post.createdAt)}
          {post.updatedAt !== post.createdAt && ` · edited ${formatDate(post.updatedAt)}`}</p>
        <div className="post-body">{post.content}</div>
        {isOwner && (
          <div className="actions">
            <Link to={`/posts/${post._id}/edit`} className="btn btn-outline btn-sm">Edit</Link>
            <button className="btn btn-danger btn-sm" onClick={remove}>Delete</button>
          </div>
        )}
      </article>
      <Comments postId={post._id} />
    </div>
  );
}
